#!/usr/bin/env python3

import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from geometry_msgs.msg import Pose, Point, Quaternion
import math

def move_base_client():
    # Initialize the ROS node
    rospy.init_node('send_goals')

    # Create an action client for MoveBase
    client = actionlib.SimpleActionClient('move_base', MoveBaseAction)

    # Wait for the action server to come up
    client.wait_for_server()

    # Define a list of four goal poses (x, y, theta)
    goals = [
        [(-3.0, 4.0, 0.0), (0.0, 0.0, 0.0, 1.0)],
        [(-6.5, 0.0, 0.0), (0.0, 0.0, 0.0, 1.0)],
        [(5.5, -1.0, 0.0), (0.0, 0.0, 0.0, 1.0)],
        [(3.0, 4.0, 0.0), (0.0, 0.0, 0.0, 1.0)],
         [(1.0, 3.0, 0.0), (0.0, 0.0, 0.0, 1.0)],
         [(-3.0, 1.0, 0.0), (0.0, 0.0, 0.0, 1.0)]
    ]

    for i, goal in enumerate(goals):
        pose = Pose(Point(*goal[0]), Quaternion(*goal[1]))

        # Create a MoveBaseGoal with the current pose
        move_goal = MoveBaseGoal()
        move_goal.target_pose.header.frame_id = 'map'
        move_goal.target_pose.header.stamp = rospy.Time.now()
        move_goal.target_pose.pose = pose

        # Send the goal to the MoveBase action server
        client.send_goal(move_goal)

        # Wait for the robot to reach the goal or for the goal to be canceled
        client.wait_for_result()

        # Check if the goal was successful
        if client.get_state() == actionlib.GoalStatus.SUCCEEDED:
            rospy.loginfo(f"Goal {i+1} reached successfully!")
        else:
            rospy.logwarn(f"Goal {i+1} was not reached.")

if __name__ == '__main__':
    try:
        move_base_client()
    except rospy.ROSInterruptException:
        rospy.loginfo("Navigation test interrupted.")
